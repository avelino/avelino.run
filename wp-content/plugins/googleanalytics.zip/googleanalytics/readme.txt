=== Google Analytics ===
Contributors: Kevin Sylvestre
Tags: javascript, google, analytics
Requires at least: 2.7
Tested up to: 2.9
Stable tag: 1.0.2

Enables google analytics on all pages.

== Description ==

This plugin adds the required javascript for google analytics.

For more information visit:

[Google Analytics](http://www.google.com/analytics)

== Installation ==

1. Upload `googleanalytics` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add the web property ID from Google Analytics (UA-0000000-0) to the settings (Admin > Settings > Google Analytics)

== Screenshots ==

1. Modified settings panel with Google Analytics.
2. Google Analytics settings page.
